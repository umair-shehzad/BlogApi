using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using BlogApi.Controllers;
using BlogApi.Data;
using BlogApi.Models;

public class PostsControllerTests
{
    private BlogContext CreateDbContext()
    {
        var options = new DbContextOptionsBuilder<BlogContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

        return new BlogContext(options);
    }

    private IMemoryCache CreateMemoryCache()
    {
        return new MemoryCache(new MemoryCacheOptions());
    }

    [Fact]
    public async Task GetPosts_ReturnsPosts_WhenPostsExist()
    {
        using var context = CreateDbContext();
        var cache = CreateMemoryCache();
        var controller = new PostsController(context, cache);
        
        context.BlogPosts.AddRange(
            new BlogPost { Title = "Post 1", Author = "Author 1" },
            new BlogPost { Title = "Post 2", Author = "Author 2" }
        );
        await context.SaveChangesAsync();

        var result = await controller.GetPosts();

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsAssignableFrom<IEnumerable<BlogPost>>(okResult.Value);
        Assert.Equal(2, returnValue.Count());
    }

    [Fact]
    public async Task GetPost_ReturnsNotFound_WhenPostDoesNotExist()
    {
        using var context = CreateDbContext();
        var cache = CreateMemoryCache();
        var controller = new PostsController(context, cache);

        var result = await controller.GetPost(1);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task CreatePost_ReturnsCreatedPost_WhenModelIsValid()
    {
        using var context = CreateDbContext();
        var cache = CreateMemoryCache();
        var controller = new PostsController(context, cache);
        var post = new BlogPost { Title = "New Post", Author = "Author 1" };

        var result = await controller.CreatePost(post);

        var createdResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        Assert.NotNull(await context.BlogPosts.FindAsync(post.Id));
    }

    [Fact]
    public async Task SearchPosts_ReturnsPosts_WhenQueryIsValid()
    {
        using var context = CreateDbContext();
        var cache = CreateMemoryCache();
        var controller = new PostsController(context, cache);
        
        context.BlogPosts.AddRange(
            new BlogPost { Title = "Post 1", Author = "Author 1" },
            new BlogPost { Title = "Searchable Post", Author = "Author 2" }
        );
        await context.SaveChangesAsync();

        var result = await controller.SearchPosts("Searchable");

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsAssignableFrom<IEnumerable<BlogPost>>(okResult.Value);
        Assert.Single(returnValue);
    }

    [Fact]
    public async Task SearchPosts_ReturnsNotFound_WhenNoPostsMatch()
    {
        using var context = CreateDbContext();
        var cache = CreateMemoryCache();
        var controller = new PostsController(context, cache);
        
        context.BlogPosts.Add(new BlogPost { Title = "Post 1", Author = "Author 1" });
        await context.SaveChangesAsync();

        var result = await controller.SearchPosts("Nonexistent");

        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result.Result);
        Assert.Equal("No posts found matching the search criteria.", notFoundResult.Value);
    }
}
