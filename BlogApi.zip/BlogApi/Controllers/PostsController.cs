using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlogApi.Data;
using BlogApi.Models;
using Microsoft.Extensions.Caching.Memory;

namespace BlogApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly BlogContext _context;
        private readonly IMemoryCache _cache;

        public PostsController(BlogContext context, IMemoryCache cache)
        {
            _context = context;
            _cache = cache;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BlogPost>>> GetPosts(int pageNumber = 1, int pageSize = 10)
        {
            string cacheKey = $"posts-page-{pageNumber}-size-{pageSize}";

            if (!_cache.TryGetValue(cacheKey, out List<BlogPost>? posts) || posts == null)
            {
                posts = await _context.BlogPosts
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                _cache.Set(cacheKey, posts, TimeSpan.FromMinutes(10));
            }

            return Ok(posts ?? new List<BlogPost>());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BlogPost>> GetPost(int id)
        {
            var post = await _context.BlogPosts.FindAsync(id);
            if (post == null)
                return NotFound();

            return Ok(post);
        }

        [HttpPost]
        public async Task<ActionResult<BlogPost>> CreatePost([FromBody] BlogPost post)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _context.BlogPosts.Add(post);
            await _context.SaveChangesAsync();

            _cache.Remove("posts");

            return CreatedAtAction(nameof(GetPost), new { id = post.Id }, post);
        }

        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<BlogPost>>> SearchPosts([FromQuery] string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                return await GetPosts();
            }

            var posts = await _context.BlogPosts
                .Where(p => p.Title.Contains(query) || p.Author.Contains(query))
                .ToListAsync();

            if (!posts.Any())
                return NotFound("No posts found matching the search criteria.");

            return Ok(posts);
        }
    }
}
